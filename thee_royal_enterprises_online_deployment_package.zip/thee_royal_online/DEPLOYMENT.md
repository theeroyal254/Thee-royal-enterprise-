# Thee Royal Enterprises — Online Deployment

This package is prepared for an online backend deployment.

## Easiest route: Render
1. Create a GitHub repository and upload the backend project.
2. Create a PostgreSQL database on your hosting provider.
3. Create the web service using `render.yaml`.
4. Add the M-PESA/Daraja values as private environment variables.
5. After deployment, test:
   `https://YOUR-DOMAIN/health`
6. Set the mobile app's `EXPO_PUBLIC_API_URL` to that HTTPS API address.
7. Rebuild the mobile app.

## Important
- Do not put M-PESA consumer secret/passkey in the mobile app.
- Do not send secrets in chat.
- The callback URL must be the public HTTPS URL of the deployed backend.
- Your phone number 0712025355 is not automatically an M-PESA shortcode; use the actual merchant/paybill/till details assigned to the business.
- For production customer wallets, use proper merchant/payment-provider arrangements and complete any applicable Kenyan regulatory requirements.

## Local test
Run:
  docker compose up --build

Then open:
  http://localhost:3000/health
