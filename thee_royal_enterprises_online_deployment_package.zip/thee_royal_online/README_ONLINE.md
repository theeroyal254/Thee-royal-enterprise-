# Thee Royal Enterprises Online Payment App

Business: Thee Royal Enterprises
Business phone: 0712025355

This is a deployment package for the payment backend. It is not yet a public URL because deployment requires a hosting account and M-PESA credentials owned by the business.

Next:
1. Upload the backend project to GitHub.
2. Deploy it using Render/Railway/a VPS.
3. Add PostgreSQL.
4. Add Daraja credentials privately.
5. Set the mobile app API URL to the deployed HTTPS address.
